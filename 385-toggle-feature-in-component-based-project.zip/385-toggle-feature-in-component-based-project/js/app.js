import { Header } from "../components/Header/header.js";
import { Course } from "../components/Course/course.js";

window.customElements.define('site-header', Header)
window.customElements.define('site-course', Course)