import { SiteUser } from "../components/site-user/site-user.js";
import { Header } from "../components/Header/header.js";

window.customElements.define('site-user', SiteUser)
window.customElements.define('site-header', Header)