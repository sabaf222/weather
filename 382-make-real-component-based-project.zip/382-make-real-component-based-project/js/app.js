import { Header } from "../components/Header/header.js";

window.customElements.define('site-header', Header)